# Pipecat Library Patches

This document tracks all modifications made to the Pipecat library in `venv/`.

## ⚠️ IMPORTANT
These patches will be **lost** if you upgrade Pipecat. Re-apply them after upgrading.

---

## Patch 1: Frame Processor Race Condition Fix

**File**: `venv/Lib/site-packages/pipecat/processors/frame_processor.py`  
**Line**: ~904-907  
**Date Applied**: December 17, 2025

**Issue**: Race condition where frames could arrive before `__process_queue` was created.

**Fix**:
```python
# In __input_frame_task_handler method:
if isinstance(frame, SystemFrame):
    await self.__process_frame(frame, direction, callback)
else:
    if not self.__process_queue:  # ✅ Added defensive check
        self.__create_process_task()
    await self.__process_queue.put((frame, direction, callback))
```

**Why Needed**: Fast LLMs could emit frames before queue initialization, causing silent frame drops.

---

## Patch 2: Aggregator Frame Forwarding Fix

**File**: `venv/Lib/site-packages/pipecat/processors/aggregators/llm_response.py`  
**Lines**: ~996, ~1000, ~1005  
**Date Applied**: December 17, 2025

**Issue**: `LLMAssistantContextAggregator` was consuming LLM frames for context but not forwarding them to TTS.

**Fix 1 - _handle_llm_start** (Line ~996):
```python
async def _handle_llm_start(self, frame: LLMFullResponseStartFrame):
    self._started += 1
    await self.push_frame(frame, FrameDirection.DOWNSTREAM)  # ✅ Added
```

**Fix 2 - _handle_llm_end** (Line ~1000):
```python
async def _handle_llm_end(self, frame: LLMFullResponseEndFrame):
    self._started -= 1
    await self.push_aggregation()
    await self.push_frame(frame, FrameDirection.DOWNSTREAM)  # ✅ Added
```

**Fix 3 - _handle_text** (Line ~1005):
```python
async def _handle_text(self, frame: TextFrame):
    if not self._started:
        return
    # Accumulate text for context
    if self._params.expect_stripped_words:
        self._aggregation += f" {frame.text}" if self._aggregation else frame.text
    else:
        self._aggregation += frame.text
    # ✅ Added: Push TextFrame downstream to TTS
    await self.push_frame(frame, FrameDirection.DOWNSTREAM)
```

**Why Needed**: Without this, TTS never receives text frames, resulting in no audio output.

---

## How to Re-apply Patches After Upgrade

### Step 1: Upgrade Pipecat
```bash
pip install --upgrade pipecat-ai
```

### Step 2: Re-apply Patch 1 (frame_processor.py)
1. Open `venv/Lib/site-packages/pipecat/processors/frame_processor.py`
2. Find the `__input_frame_task_handler` method (around line 890)
3. Locate this code:
   ```python
   if isinstance(frame, SystemFrame):
       await self.__process_frame(frame, direction, callback)
   elif self.__process_queue:
       await self.__process_queue.put((frame, direction, callback))
   else:
       raise RuntimeError(...)
   ```
4. Replace with:
   ```python
   if isinstance(frame, SystemFrame):
       await self.__process_frame(frame, direction, callback)
   else:
       if not self.__process_queue:
           self.__create_process_task()
       await self.__process_queue.put((frame, direction, callback))
   ```

### Step 3: Re-apply Patch 2 (llm_response.py)
1. Open `venv/Lib/site-packages/pipecat/processors/aggregators/llm_response.py`
2. Find `_handle_llm_start` (around line 996) and add:
   ```python
   await self.push_frame(frame, FrameDirection.DOWNSTREAM)
   ```
3. Find `_handle_llm_end` (around line 1000) and add:
   ```python
   await self.push_frame(frame, FrameDirection.DOWNSTREAM)
   ```
4. Find `_handle_text` (around line 1005) and add:
   ```python
   await self.push_frame(frame, FrameDirection.DOWNSTREAM)
   ```

### Step 4: Clear Cache and Test
```bash
# Clear Python cache
Get-ChildItem -Recurse -Include "__pycache__","*.pyc" | Remove-Item -Recurse -Force

# Restart server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

---

## Alternative: Use Git Patch Files

You can create patch files for easier re-application:

```bash
# Create patches (before upgrading)
cd venv/Lib/site-packages/pipecat
git diff processors/frame_processor.py > ~/frame_processor.patch
git diff processors/aggregators/llm_response.py > ~/llm_response.patch

# Apply patches (after upgrading)
cd venv/Lib/site-packages/pipecat
git apply ~/frame_processor.patch
git apply ~/llm_response.patch
```

---

## When to Remove These Patches

Monitor Pipecat releases. These patches may become unnecessary when:
- Pipecat fixes the frame processor race condition
- Pipecat updates aggregator to forward frames to TTS

Check release notes: https://github.com/pipecat-ai/pipecat/releases

---

## Current Pipecat Version
- **Version**: 0.0.95
- **Patches Applied**: 2
- **Last Verified**: December 17, 2025

# 🔊 Audio Not Reaching User - Final Issue

## Current Status

✅ **Everything is working on the server side:**
- STT receives audio and transcribes ✅
- LLM generates responses ✅  
- Aggregator passes frames to TTS ✅
- TTS generates audio ✅
- Transport shows "Bot started speaking" ✅

❌ **But user doesn't hear audio on phone**

## Root Cause

The `TwilioFrameSerializer` is configured with `stream_sid=None` which means it should auto-bind when receiving Twilio's start message. However, the audio is not reaching the user's phone.

## Possible Issues

### 1. Stream SID Not Bound
The serializer might not be binding to the correct stream_sid.

### 2. Audio Format Mismatch
- TTS outputs: `linear16` PCM at 8kHz
- Twilio expects: `mulaw` at 8kHz
- The serializer should convert, but might not be working

### 3. WebSocket Not Sending Audio
The transport might not be sending audio frames back to Twilio.

## Solution: Pass Stream SID to Serializer

Modify `transport/twilio.py` to accept and use the stream_sid:

```python
def create_twilio_transport(
    websocket: WebSocket,
    stream_sid: str,  # ✅ Now required!
    language: str = None
) -> FastAPIWebsocketTransport:
    
    # ... VAD config ...
    
    # ✅ Pass stream_sid to serializer
    serializer = TwilioFrameSerializer(
        stream_sid=stream_sid,  # ✅ Use the extracted stream_sid
        params=TwilioFrameSerializer.InputParams(
            auto_hang_up=False
        )
    )
    
    # ... rest of config ...
```

Then in `api/routes/websocket.py`, pass the extracted stream_sid:

```python
transport = create_twilio_transport(
    websocket,
    stream_sid=stream_sid,  # ✅ Pass extracted stream_sid
    language=language,
)
```

## Alternative: Check TTS Audio Format

The TTS is configured to output `linear16` but Twilio needs `mulaw`. Check if the serializer is converting properly.

In `pipeline/builder.py`, the TTS config shows:
```python
'output_audio_codec': 'linear16'
```

This should be fine as the `TwilioFrameSerializer` converts PCM to mulaw. But verify the sample rate matches:
- TTS: 8000 Hz ✅
- Twilio: 8000 Hz ✅

## Debug Steps

### 1. Add Logging to Transport
Add logs to see if audio frames are being sent:

```python
# In transport output, add logging
logger.info(f"🔊 Sending audio frame to Twilio: {len(audio_data)} bytes")
```

### 2. Check Twilio Console
- Go to Twilio Console → Monitor → Logs
- Check if media frames are being received
- Look for any errors

### 3. Test with Simple Audio
Try sending a test tone to verify the transport works.

## Most Likely Fix

The issue is that `stream_sid=None` prevents the serializer from knowing which Twilio stream to send audio to. 

**Apply the fix above to pass the extracted stream_sid to the serializer.**


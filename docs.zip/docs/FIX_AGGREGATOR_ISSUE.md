# 🎯 ROOT CAUSE FOUND: Aggregator Blocking TTS Frames

## The Problem

The `LLMAssistantContextAggregator` is **consuming TextFrames** and NOT pushing them to TTS!

### What's Happening:

1. LLM pushes `LLMTextFrame` → Aggregator
2. Aggregator's `_handle_text()` accumulates the text
3. **Aggregator DOES NOT push frame to TTS** ❌
4. TTS never receives any text
5. No audio generated

### Code Evidence:

```python
# In LLMAssistantContextAggregator.process_frame():
elif isinstance(frame, TextFrame):
    await self._handle_text(frame)  # ❌ Consumes frame, doesn't push!

# In _handle_text():
async def _handle_text(self, frame: TextFrame):
    if not self._started:
        return
    # Just accumulates text, doesn't push frame!
    self._aggregation += frame.text
```

## The Solution

We have TWO options:

### Option 1: Modify Aggregator (Risky - modifies Pipecat internals)
Patch `venv/Lib/site-packages/pipecat/processors/aggregators/llm_response.py`:
```python
async def _handle_text(self, frame: TextFrame):
    if not self._started:
        return
    
    # Accumulate for context
    if self._params.expect_stripped_words:
        self._aggregation += f" {frame.text}" if self._aggregation else frame.text
    else:
        self._aggregation += frame.text
    
    # ✅ ALSO push to TTS!
    await self.push_frame(frame, FrameDirection.DOWNSTREAM)
```

### Option 2: Bypass Aggregator (Recommended - cleaner)
Modify YOUR LLM service to push frames that bypass the aggregator's text handling.

The aggregator is designed for **context management**, not for **streaming to TTS**.

## Recommended Fix: Use Direct Frame Flow

The correct Pipecat 0.0.95 pattern is:

```
LLM → TextFrame → TTS (direct)
LLM → ContextFrame → Aggregator (for context only)
```

NOT:
```
LLM → TextFrame → Aggregator → ??? (blocked!)
```

### Implementation:

Your LLM should:
1. Push `LLMFullResponseStartFrame` 
2. Push `TextFrame` (NOT LLMTextFrame) directly - these go to TTS
3. Push `LLMFullResponseEndFrame`
4. Aggregator handles start/end frames for context
5. TTS receives TextFrames directly

OR remove the aggregator from the pipeline if you're managing context yourself!

